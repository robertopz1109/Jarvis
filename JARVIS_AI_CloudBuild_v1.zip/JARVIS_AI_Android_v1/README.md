# JARVIS AI – Android starter v1.0

A first native Android prototype for a Samsung Galaxy S25.

## Included
- Tap-to-talk voice input using Android SpeechRecognizer.
- In-app "Hey Jarvis" wake phrase mode while the app is open and visible.
- Spoken responses using Android TextToSpeech.
- Basic demo commands: greeting, time, date, identity, open YouTube, open camera.
- Dark futuristic interface.

## Important limitations
- This is source code, not a compiled APK.
- Wake phrase detection is a foreground prototype only. It is not an always-on background hotword service and may stop when Android suspends the app or speech recognition service.
- The speech recognizer is configured for UK English (`en-GB`) in this starter.
- Android TextToSpeech uses the voice selected on the phone. To choose a male voice if available, check Settings > General management > Text-to-speech output.
- Advanced conversational AI is not connected yet. A secure backend/API integration is a later development step; do not put private API keys in the Android app.
- Opening apps depends on those apps being installed and permitted by Android.

## Build in Android Studio
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the `JARVIS_AI_Android_v1` folder in Android Studio.
4. Allow Gradle sync to finish. Use JDK 17.
5. Connect the Samsung S25 with USB debugging enabled, or use wireless debugging.
6. Press Run to install the app on the phone.
7. Grant microphone permission when prompted.

To create an APK: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).

## Next development milestones
1. Add reliable bilingual language selection (English/Spanish).
2. Connect an AI model through a secure backend.
3. Add app shortcuts and user-approved phone actions.
4. Investigate a compliant foreground-service wake-word approach with clear microphone indicators and battery controls.
5. Add settings, personalization, and privacy controls.

## Cloud build without a computer (GitHub Actions)

This project includes `.github/workflows/android-apk.yml`.
1. Create a private repository on GitHub from your phone.
2. Upload the contents of this project folder to the repository (keep the `.github/workflows` folder).
3. Open the repository's **Actions** tab and run **Build JARVIS AI APK** (or wait for the first push build).
4. When the run finishes successfully, open it and download the `JARVIS_AI_debug_APK` artifact.
5. Extract the downloaded artifact on your Samsung and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

This is a debug/test APK, not a Play Store release. The app selects Spanish or UK English from the phone's current language. The installed system text-to-speech voice is used; a male voice is not guaranteed and must be selected in Samsung text-to-speech settings if available.

The wake phrase is still a foreground experiment and requires the app to remain open. This build does not add a cloud AI service or always-on background listening.
