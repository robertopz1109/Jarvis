package com.jarvis.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var listenButton: Button
    private lateinit var wakeButton: Button
    private var wakeMode = false
    private var waitingForCommand = false
    private var ttsReady = false

    private val blue = Color.rgb(40, 168, 255)
    private val dark = Color.rgb(5, 10, 18)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        buildScreen()
        tts = TextToSpeech(this, this)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        } else {
            setupRecognizer()
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 34, 24, 24)
            setBackgroundColor(dark)
        }

        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 30f
            setTextColor(blue)
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT  •  VERSION 1.0"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(subtitle)

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 92f
            setTextColor(blue)
            gravity = Gravity.CENTER
        }
        root.addView(orb, LinearLayout.LayoutParams(-1, 150))

        status = TextView(this).apply {
            text = "SYSTEM READY"
            textSize = 14f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        root.addView(status)

        listenButton = makeButton("TALK TO JARVIS") {
            if (hasMicPermission()) {
                wakeMode = false
                waitingForCommand = false
                startListening()
            } else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        }
        root.addView(listenButton, buttonParams())

        wakeButton = makeButton("ENABLE “HEY JARVIS”") {
            if (!hasMicPermission()) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
            } else {
                wakeMode = !wakeMode
                waitingForCommand = false
                wakeButton.text = if (wakeMode) "DISABLE WAKE WORD" else "ENABLE “HEY JARVIS”"
                if (wakeMode) startListening() else {
                    recognizer?.cancel()
                    status.text = "WAKE WORD OFF"
                }
            }
        }
        root.addView(wakeButton, buttonParams())

        val label = TextView(this).apply {
            text = "CONVERSATION"
            textSize = 11f
            setTextColor(blue)
            setPadding(0, 22, 0, 8)
        }
        root.addView(label)

        conversation = TextView(this).apply {
            text = "JARVIS: Good day. I am ready to assist you.\nJARVIS: Hola. Estoy listo para ayudarte."
            textSize = 15f
            setTextColor(white)
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(12, 22, 36))
            addView(conversation)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(white)
        setBackgroundColor(Color.rgb(13, 75, 125))
        setOnClickListener { action() }
        isAllCaps = false
    }

    private fun buttonParams() = LinearLayout.LayoutParams(-1, 58).apply {
        setMargins(0, 7, 0, 7)
    }

    private fun hasMicPermission() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "SPEECH RECOGNITION UNAVAILABLE"
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = if (wakeMode) "LISTENING FOR HEY JARVIS" else "LISTENING..." }
            override fun onBeginningOfSpeech() { status.text = "I'M LISTENING" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "PROCESSING..." }
            override fun onError(error: Int) {
                if (wakeMode) {
                    status.postDelayed({ if (wakeMode) startListening() }, 650)
                } else status.text = "TAP TALK TO TRY AGAIN"
            }
            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                handleRecognizedText(heard)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (recognizer == null) setupRecognizer()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val deviceLanguage = if (Locale.getDefault().language == "es") "es-ES" else "en-GB"
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, deviceLanguage)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, deviceLanguage)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) {
            status.text = "COULD NOT START MICROPHONE"
        }
    }

    private fun handleRecognizedText(raw: String) {
        if (raw.isBlank()) {
            if (wakeMode) startListening() else status.text = "I DIDN'T CATCH THAT"
            return
        }
        val lower = raw.lowercase(Locale.ROOT)
        if (wakeMode && !waitingForCommand) {
            val wakePhrases = listOf("hey jarvis", "ok jarvis", "okay jarvis", "jarvis")
            if (wakePhrases.any { lower.contains(it) }) {
                waitingForCommand = true
                val remainder = wakePhrases.firstNotNullOfOrNull { phrase ->
                    if (lower.contains(phrase)) lower.substringAfter(phrase).trim() else null
                }.orEmpty()
                if (remainder.isNotBlank()) {
                    respondTo(remainder)
                } else {
                    speak("I'm listening. What can I do for you?")
                    status.text = "JARVIS ACTIVATED"
                    startListening()
                }
            } else startListening()
            return
        }
        waitingForCommand = false
        respondTo(raw)
    }

    private fun respondTo(command: String) {
        addLine("YOU: $command")
        val q = command.lowercase(Locale.ROOT)
        val answer = when {
            q.contains("hello") || q.contains("hola") -> "Hola, Roberto. ¿En qué puedo ayudarte? Hello, Roberto. How can I assist you?"
            q.contains("time") || q.contains("hora") -> "The time on your phone is ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())}."
            q.contains("date") || q.contains("fecha") || q.contains("day") -> "Today is ${java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(java.util.Date())}."
            q.contains("who are you") || q.contains("quien eres") -> "Soy Jarvis, tu asistente personal, Roberto. I am Jarvis, your personal assistant, Roberto."
            q.contains("open youtube") || q.contains("abre youtube") -> {
                openApp("com.google.android.youtube")
                "Opening YouTube, if it is installed."
            }
            q.contains("open camera") || q.contains("abre cámara") || q.contains("abre camara") -> {
                val camera = packageManager.getLaunchIntentForPackage("com.sec.android.app.camera")
                if (camera != null) startActivity(camera)
                "Opening the camera, if available."
            }
            q.contains("stop listening") || q.contains("deja de escuchar") -> {
                wakeMode = false
                wakeButton.text = "ENABLE “HEY JARVIS”"
                "Wake word disabled."
            }
            else -> "I heard you say: $command. My basic version is working. Advanced AI answers will be connected in a future update."
        }
        addLine("JARVIS: $answer")
        speak(answer)
        status.text = "READY"
        if (wakeMode) startListening()
    }

    private fun openApp(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }

    private fun addLine(line: String) {
        conversation.append("\n\n$line")
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val speechLocale = if (Locale.getDefault().language == "es") Locale("es", "ES") else Locale.UK
            val result = tts?.setLanguage(speechLocale)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            // Android uses the selected system TTS voice. Choose a male English voice in device settings if available.
            tts?.setSpeechRate(0.92f)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            setupRecognizer()
            status.text = "MICROPHONE READY"
        } else if (requestCode == 101) status.text = "MICROPHONE PERMISSION REQUIRED"
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
